#!/bin/bash

sudo hwclock -s

extractPATH='/home/pi/extractAWSdata'
ttyusb=$(ls -l /dev/serial/by-id|grep USB_to_UART|awk '{print substr($0,length($0)- 6,length($0))}')

$extractPATH/wx -s /dev/$ttyusb
