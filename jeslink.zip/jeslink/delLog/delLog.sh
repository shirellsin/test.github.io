#!/bin/bash

#change path is necessary
extractOutPATH='/home/jeslink/data'
YYYYMM=$(date --date='13 months ago' +"%Y%m")

rm -r $extractOutPATH/csv/$YYYYMM
rm -r $extractOutPATH/txt/$YYYYMM
