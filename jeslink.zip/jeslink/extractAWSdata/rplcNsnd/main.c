#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <getopt.h>

#define BUFFERSIZE 32767

/* local Data */
static bool bVerbose;                   /* Verbose Mode */
static char szTmplFileName[256];        /* template filename */
static char szDataFileName[256];        /* data filename */
static FILE *pfTmpl = 0;                /* template file handle */
static char *pDMem;                     /* data file memory pointer */


/* local functions */
static int GetParms(int argc, char *argv[]);
static int ParseInputFile(void);
static void SkipWhiteSpace(char **pData);
static void SkipToWhiteSpace(char **pData);
static int GetVarValue(char *pRtnVal, char *pStart, char *pEnd);


/*--------------------------------------------------------------------------
    main
----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    FILE *pfData = 0;               /* data file handle */
    int i;
    long lSize;

    /* Get command line parms */
    if (!GetParms(argc, argv)) {
/*
        printf("\nUsage: vproreplace [-v] -t templatefile -d datafile \n");
        printf("Options:\n");
        printf(" -v, --verbose         Verbose mode.\n");
        printf(" -t, --template=file   name of template file to parse.\n");
        printf(" -d, --data=file       name of vproweather data file.\n");
        printf("\n");
        printf("Examples:\n");
        printf("vproreplace -t weather.html -d rtcdata > final.html\n");
        printf("Parses file weather.html and writes output to final.html\n");
*/
        exit(2);
    }

    if(!strlen(szTmplFileName))
    {
        fprintf(stderr, "Template file not specified.\n");
        exit(2);
    }

    if(!strlen(szDataFileName))
    {
        fprintf(stderr, "Data file not specified.\n");
        exit(2);
    }


    /* open the template file */
    if(bVerbose)
        printf("Opening template file '%s'...\n", szTmplFileName);
    pfTmpl = fopen(szTmplFileName, "r");
    if(!pfTmpl)
    {
        perror("Can't open template file for reading");
        exit(2);
    }


    /* open the data file */
    if(bVerbose)
        printf("Opening data file '%s'...\n", szDataFileName);
    pfData = fopen(szDataFileName, "rb");
    if(!pfData)
    {
        perror("Can't open data file for reading");
        fclose(pfTmpl);
        exit(2);
    }

    /* get data file to memory */
    fseek(pfData, 0L, SEEK_END);        /* get size of file */
    lSize = ftell(pfData);
    pDMem = malloc(lSize + 16);         /* get memory for data file */
    if(pDMem == NULL) {
        fprintf(stderr, "can't allocate needed memory.\n");
        return 2;
    }
    memset(pDMem, 0, lSize+16);
    fseek(pfData, 0L, SEEK_SET);        /* copy file to memory */
    i = fread(pDMem, 1, lSize, pfData);
    fclose(pfData);


    i = ParseInputFile();       /* go do it */

    /* all done */
    fclose(pfTmpl);             /* close input files */

    exit(i);

}





/*--------------------------------------------------------------------------
    GetParms
    Reads command line parameters.
----------------------------------------------------------------------------*/
int GetParms(int argc, char *argv[])
{
    extern char *optarg;
    extern int optind, opterr, optopt;
    int c;

     /* options descriptor */
    static struct option longopts[] = {
        { "verbose",    no_argument,        0,  'v' },
        { "template",   required_argument,  0,  't' },
        { "data",       required_argument,  0,  'd' },
        { NULL,             0,              NULL,   0 }
    };

    /* Set command line defaults */
    *szTmplFileName = '\0';
    *szDataFileName = '\0';
    bVerbose = false;

    while ((c = getopt_long(argc, argv, "vt:d:", longopts, NULL )) != EOF) {
        switch (c) {
            case 'v':
                bVerbose= true;
                break;

            case 't':                           /* template file name */
                strcpy(szTmplFileName, optarg);
                break;

            case 'd':                           /* data file name */
                strcpy(szDataFileName, optarg);
                break;

            case '?': /* user entered unknown option */
            case ':': /* user entered option without required value */
            case 'h': /* User wants Usage message */
                return 0;

            default:
                break;

        }
    }
    return -1;
}



/*--------------------------------------------------------------------------
    ParseInputFile
    Scan through the input file and replace the strings. Returns zero if
    successful.
----------------------------------------------------------------------------*/
int ParseInputFile(void)
{
    char *pLine;                /* line buffer */
    char *pBeg;                 /* pointer to lead-in '<!--' */
    char *pEnd;                 /* pointer to lead-out '-->' */
    char *pPos;                 /* current position in line */
    char *pVarBeg, *pVarEnd;    /* beginning, end of variable */
    char *pValue;               /* Value buffer */

    pValue = malloc(4096);      /* get memory for value buffer */
    if(pValue == NULL) {
        fprintf(stderr, "can't allocate pValue memory.\n");
        return 2;
    }

    pLine = malloc(BUFFERSIZE); /* get memory for line buffer */
    if(pLine == NULL) {
        fprintf(stderr, "can't allocate pLine memory.\n");
        return 2;
    }

    /* scan each line, looking for the lead-in */
    while(fgets(pLine, BUFFERSIZE, pfTmpl) != NULL) {   /* get next line */

        pPos = pLine;                   /* start at the beginning of the line */

    _nextpos:
        pBeg = strstr(pPos, "<!--");    /* search for lead-in */
        if(pBeg == NULL) {
            /* didn't find a lead-in, hit end-of-line */
            fwrite(pPos, 1, strlen(pPos), stdout);
            continue;
        }
        /* got a lead-in */
        pVarBeg = pBeg+4;               /* make pBeg = start of whitespace */
        SkipWhiteSpace(&pVarBeg);       /* pVarBeg = 1st char of var */
        pVarEnd = pVarBeg;
        SkipToWhiteSpace(&pVarEnd);     /* pVarEnd = last char of var */
        pEnd = pVarEnd;
        SkipWhiteSpace(&pEnd);
        if(strstr(pEnd, "-->") == pEnd) {
            if(GetVarValue(pValue, pVarBeg, pVarEnd)) {
                /* found the value */
                fwrite(pPos, 1, pBeg - pPos, stdout); /* write up to lead-in */
                fwrite(pValue, 1, strlen(pValue), stdout); /* write var */
                pPos = pEnd + 3;        /* move pos to end of this mess */
                goto _nextpos;
            }
            else {
                /* unrecognized var, write as is */
                fwrite(pPos, 1,  pEnd - pPos + 3, stdout);
                pPos = pEnd + 3;    /* move pos to end of this mess */
                goto _nextpos;
            }
        }
        else {
            /* no lead-out! Something's fucked up, so give up */
            fwrite(pPos, 1, pEnd - pPos, stdout);
            pPos = pEnd;
            goto _nextpos;
        }
    }

    free(pLine);
    free(pValue);
    return 0;
}




/*--------------------------------------------------------------------------
    SkipWhiteSpace
    increments the passed pointer to the first non-whitespace character.
---------------------------------------------------------------------------*/
void SkipWhiteSpace(char **pData)
{
    while( (**pData == ' ') || (**pData == '\t') )
        ++(*pData);
}




/*--------------------------------------------------------------------------
    SkipToWhiteSpace
    increments the passed pointer to the first whitespace character.
---------------------------------------------------------------------------*/
void SkipToWhiteSpace(char **pData)
{
    while( (**pData != ' ') && (**pData != '\t') && (**pData != '\n') &&
            (**pData != '\0') && (**pData != '-') )
        ++(*pData);
}





/*--------------------------------------------------------------------------
    GetVarValue
    Searches the data file for the passed var value, returning a string
    representing the value. Returns zero if the var was not found.
---------------------------------------------------------------------------*/
int GetVarValue(char *pRtnVal, char *pStart, char *pEnd)
{
    char szVar[64];
    char *p, *pBrak;
    int nIndex, i;

    strncpy(szVar, pStart, pEnd - pStart);
    szVar[pEnd - pStart] = '\0';
    if(!strlen(szVar))
        return 0;                           /* empty var */

    /* if there are brackets, it's an array */
    pBrak = strchr(szVar, '[');
    if(pBrak) {
        /* caller wants an array element */
        *pBrak = '\0';                      /* chop off array subscript */
        nIndex = atoi(pBrak+1);
        if( (nIndex > 25) || (nIndex < 0))  /* sanity check */
            return 0;
        p = strstr(pDMem, szVar);
        if(p == NULL)
            return 0;                       /* var not found, return */

        /* found the variable */
        while( (*p != '=') && (*p != '\n') && (*p != '\0') )
            ++p;

        if(*p != '=')
            return 0;                       /* didn't find equal sign */
        ++p;
        SkipWhiteSpace(&p);

        /* scan the comma-separated string for the index requested */
        for(i = 0; i < nIndex; i++) {
            while( (*p != ',') && (*p != '\n') && (*p != '\0') )
                ++p;
            if((*p == '\n') || (*p == '\0') )
                return 0;                   /* never found it */
            ++p;
        }

        /* copy up to next comma or newline */
        while( (*p != ',') && (*p != '\n') && (*p != '\0') )
            *pRtnVal++ = *p++;
                ++p;
    }

    else {
        p = strstr(pDMem, szVar);
        if(p == NULL)
            return 0;                   /* string not found, return */

        /* found the variable */
        while( (*p != '=') && (*p != '\n') && (*p != '\0') )
            ++p;

        if(*p != '=')
            return 0;                   /* didn't find equal sign */
        ++p;
        SkipWhiteSpace(&p);

        while((*p != '\n') && (*p != '\0'))
            *pRtnVal++ = *p++;
    }

    *pRtnVal = '\0';                    /* success */
    return 1;
}
