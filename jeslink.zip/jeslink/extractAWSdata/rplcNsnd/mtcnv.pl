#!/usr/bin/perl
#
# This program will take any datafile from Joe Jaworski's VproWeather
# System and replace some of the variables with localised values.
# (Mainly performs metric conversions.)
#
# Each section has a short description of functionality and can
# be removed if the function is not required.
# For example, if you do not wish to change the date from mm/dd to
# dd/mm format, just delete the "Swap Days and Months" section.
#
#######################################################################
#
while (<STDIN>) {
  $parm   = substr( $_, 0, index( $_, "=" ) );
  $indx1  = index( $_, "=" ) + 2;
  $indx2  = index( $_, "\n" );
  @values = split /,/, substr( $_, $indx1, $indx2 - $indx1 );
  $count  = @values; # number of values - for hi/lo and graphs
#
########################################################################
#        Convert degrees Fahrenheit (F) to degrees Celsius (C)         #
#                                                                      #
  if ($parm =~ /(Temp|Heat|Chill|Dew)/ & !  ( /Time/ | /Date/ )) {
    print STDOUT "$parm= ";
    for (@values) {
      $_ = ( $_ - 32 ) / 1.8 if ($_ gt 0) ;
      printf STDOUT "%1.1f", $_;
      print STDOUT "," if ( --$count gt 0 );
    }
    print STDOUT "\n";
  }

#                                                                      #
#                                                                      #
########################################################################
#                   Convert Inches to Millimeters                      #
#                                                                      #
  elsif ($parm =~ /Rain/ & ! (/Time/ | /Date/ | /rtIsRaining/)) {
    print STDOUT "$parm= ";
    for (@values) {
      #rain collector: 0.2mm (comment the following if 0.01 in)
      $_ = $_*0.2/0.25399956;
      $_ *= 25.399956;
      printf STDOUT "%1.1f", $_;
      print STDOUT "," if ( --$count gt 0 );
    }
    print STDOUT "\n";
  }

#                                                                      #
#                                                                      #
########################################################################
#                     Convert Miles to Kilometers                      #
#                                                                      #
  elsif ($parm =~  /Wind/ & !(/Dir/ | /Date/ | /Time/)) {
    print STDOUT "$parm= ";
    for (@values) {
      $_ *= 1.609344;
      printf STDOUT "%1.0f", $_;
      print STDOUT "," if ( --$count gt 0 );
    }
    print STDOUT "\n";
  }

#                                                                      #
#                                                                      #
########################################################################
#          Inches of mercury @32?F (inHg32) to millibars (mb)          #
#                                                                      #
  elsif ($parm =~ /(gr|hl|rt)Bar/ & !(/Time/ | /Trend/)) {
    print STDOUT "$parm= ";
    for (@values) {
      $_ *= 33.8639;
      printf STDOUT "%1.1f", $_;
      print STDOUT "," if ( --$count gt 0 );
    }
    print STDOUT "\n";
  }

#                                                                      #
#                                                                      #
########################################################################
#                         Swap Days and Months                         #
#                                                                      #
  elsif ($parm =~ /grTimeRefDays/) {
    print STDOUT "$parm= ";
    for (@values) {
      @dates = split /\//, $_;
      print STDOUT "$dates[1]/$dates[0]";
      print STDOUT "," if ( --$count gt 0 );
    }
    print STDOUT "\n";
  }

#                                                                      #
#                                                                      #
########################################################################
#                 Replace "Precipitation" with "Rain"                  #
#                                                                      #
  elsif ($parm =~ /rtForecast/) {
    s/Precipitation/Rain/g;
    print STDOUT "$_";
  }

#                                                                      #
#                                                                      #
########################################################################
  else {
    print STDOUT "$_";
  }
}
