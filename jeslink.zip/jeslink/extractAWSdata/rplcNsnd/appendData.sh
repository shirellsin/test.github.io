#!/bin/bash

sudo hwclock -s

YYYYMM=$(date +"%Y%m")
csvfilename=$(date +"%Y%m%d").csv
txtfilename=$(date +"%Y%m%d").txt

extractPATH='/home/pi/extractAWSdata'
rpNsdPATH='/home/pi/extractAWSdata/rplcNsnd'
#change path is necessary
#dataPATH='/home/pi/extractAWSdata/rplcNsnd/data'
dataPATH='/home/jeslink/data'
webPATH='/var/www/html'
ttyusb=$(ls -l /dev/serial/by-id|grep USB_to_UART|awk '{print substr($0,length($0)- 6,length($0))}')

for i in 1 2 3 4 5
do
   $extractPATH/wx -x /dev/$ttyusb > $rpNsdPATH/crrntDt
   if [ $(du -k $rpNsdPATH/crrntDt | cut -f1) != 0 ]
   then
      echo DavisTime = $(date +"%d/%m/%Y %H:%M") >> $rpNsdPATH/crrntDt
      echo DavisTime_web = $(date +"%d %b %Y, %H:%M") >> $rpNsdPATH/crrntDt
      perl $rpNsdPATH/mtcnv.pl < $rpNsdPATH/crrntDt > $rpNsdPATH/cnvDt
      $rpNsdPATH/rplc -t $rpNsdPATH/tmpltCSV -d $rpNsdPATH/cnvDt > $rpNsdPATH/crrntCSV
      $rpNsdPATH/rplc -t $rpNsdPATH/tmpltTXT -d $rpNsdPATH/cnvDt > $rpNsdPATH/crrntTXT
      $rpNsdPATH/rplc -t $rpNsdPATH/weather.sxml -d $rpNsdPATH/cnvDt > $webPATH/weather.xml
      if [ ! -d $dataPATH/csv/$YYYYMM/ ]
      then
         mkdir $dataPATH/csv/$YYYYMM/
         chown jeslink:jeslink $dataPATH/csv/$YYYYMM/
      fi
      if [ ! -d $dataPATH/txt/$YYYYMM/ ]
      then
         mkdir $dataPATH/txt/$YYYYMM/
         chown jeslink:jeslink $dataPATH/txt/$YYYYMM/
      fi
      if [ ! -f $dataPATH/csv/$YYYYMM/$csvfilename ]
      then
         cat $rpNsdPATH/titleCSV > $dataPATH/csv/$YYYYMM/$csvfilename
      fi
      if [ ! -f $dataPATH/txt/$YYYYMM/$txtfilename ]
      then
         cat $rpNsdPATH/titleTXT > $dataPATH/txt/$YYYYMM/$txtfilename
      fi
      cat $rpNsdPATH/crrntCSV >> $dataPATH/csv/$YYYYMM/$csvfilename
      cat $rpNsdPATH/crrntTXT >> $dataPATH/txt/$YYYYMM/$txtfilename
      #remove ^@ null char
      sed -i 's/\x0//g' $dataPATH/csv/$YYYYMM/$csvfilename
      sed -i 's/\x0//g' $dataPATH/txt/$YYYYMM/$txtfilename
      #remove new lines
      sed -i '/^$/d' $dataPATH/csv/$YYYYMM/$csvfilename
      sed -i '/^$/d' $dataPATH/txt/$YYYYMM/$txtfilename
      chown jeslink:jeslink $dataPATH/csv/$YYYYMM/$csvfilename
      chown jeslink:jeslink $dataPATH/txt/$YYYYMM/$txtfilename
      break
   fi
done
