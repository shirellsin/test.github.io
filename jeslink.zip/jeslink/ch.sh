#!/bin/bash

cpuserial=`cat /proc/cpuinfo | grep Serial | cut -d ' ' -f 2`
match=0
#listofcpuserial=("000000004d754df1" "000000004d754df2" "000000004d754df3")
listofcpuserial=("00000000f921e4b5")

for i in "${listofcpuserial[@]}"
do
  if [ $i = $cpuserial ]
  then
    match=1
  fi
done

if [ $match = 1 ]
then
  echo "Sound Card State Restored"
else
  echo "Sound Card State Not Restored"
  sudo halt -p
fi
